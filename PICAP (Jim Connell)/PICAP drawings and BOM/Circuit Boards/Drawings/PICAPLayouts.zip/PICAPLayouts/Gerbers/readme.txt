
9-JUL-2012  University of New Hampshire
Project: PICAP

Board Information:
Material: FR-4
Thickness: 62 mil.
Layers: 2.

Smallest hole size: 15 mil.
Smallest trace: 10 mil.
Smallest spacing: 10 mil.

Board Outline:
The board outline is shown in MASK1.GBR as a 10 mil line with the outline reference being the center of the 10 mil line.

Board:
 PICAP_DYS_V2 Size: 2.60 in. X 2.60 in.
 PICAP_DYT_V2 Size: 1.85 in. X 1.97 in.
 PICAP_PIN_V2 Size: .827 in. X .827 in.


Excellon Drill File:
DRILL.TXT

Stack up GERBER_RS274X file names:
SILK1.GBR
MASK1.GBR
LAYER1.GBR
LAYER2.GBR
MASK2.GBR
